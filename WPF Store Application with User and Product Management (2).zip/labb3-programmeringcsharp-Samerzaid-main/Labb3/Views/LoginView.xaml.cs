﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Labb3ProgTemplate.Managerrs;
using Labb3ProgTemplate.DataModels.Users;

namespace Labb3ProgTemplate.Views
{
    /// <summary>
    /// Interaction logic for LoginView.xaml
    /// </summary>
    public partial class LoginView : UserControl
    {
        public LoginView()
        {
            InitializeComponent();
            UserManager.CurrentUserChanged += UserManager_CurrentUserChanged;
            UserManager.UserListChanged += UserManager_UserListChanged;
        }
        private async void UserManager_UserListChanged()
        {
            await UserManager.SaveUsersToFile();
            await UserManager.LoadUsersFromFile();
        }

        private void UserManager_CurrentUserChanged()
        {
            //
        }

        private void LoginBtn_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            string loginName = this.LoginName.Text;
            string loginPassword = this.LoginPwd.Password;
            User user = UserManager.LogIn(loginName, loginPassword);
            if (user != null)
                MessageBox.Show("Du har inloggad as ("+ loginName +")");
            else
                MessageBox.Show(loginName+ " hittades inte");
        }

        private void RegisterAdminBtn_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            string loginName = this.RegisterName.Text;
            string loginPassword = this.RegisterPwd.Password;


            if (UserManager.RegisterAdmin(loginName, loginPassword))
                MessageBox.Show("Du har Registrerat " + loginName + " som en ny admin");
            else
                MessageBox.Show( "Misslyckades registrera admin som " + loginName);
        }

        private void RegisterCustomerBtn_OnClickmerBtn_Click(object sender, RoutedEventArgs e)
        {
            string loginName = this.RegisterName.Text;
            string loginPassword = this.RegisterPwd.Password;


            if (UserManager.RegisterCustomer(loginName, loginPassword))
                MessageBox.Show( loginName + " Har registrerat som en ny Customer ");
            else
                MessageBox.Show("Misslyckades registrera customer som" + loginName);
        }
    }
}
