﻿using Labb3ProgTemplate.DataModels.Products;
using System;
using System.Collections.Generic;
//using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Newtonsoft.Json;
using System.IO;

namespace Labb3ProgTemplate.Managerrs;

public static class ProductManager
{
    private static readonly IEnumerable<Product>? _products = new List<Product>();
    public static IEnumerable<Product> Products => _products;
    
    // Skicka detta efter att produktlistan ändrats eller lästs in
    public static event Action ProductListChanged;

    public static void AddProduct(Product product)
    {

        if (product != null)
        {
            Product prod = Products.Where(x => x.Name == product.Name && x.Price == product.Price).FirstOrDefault();
            if (prod != null)
                throw new Exception("Du har redan lagt till denna produkt!");

            Products produkt = new Products(product.Name, product.Price);

            ((List<Product>)_products).Add(produkt);

            ProductListChanged?.Invoke();
        }
    }

    public static void RemoveProduct(Product produkt)
    {
        ((List<Product>)_products).Remove(produkt);
        ProductListChanged?.Invoke();
    }

    public static async Task SaveProductsToFile()
    {
        try
        {
            string productFilePath =
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "products.json");
            using (StreamWriter writer = new StreamWriter(productFilePath))
            {
                string productJson = JsonConvert.SerializeObject(ProductManager.Products, Formatting.Indented);
                await writer.WriteAsync(productJson);
            }

        }
        catch (Exception ex)
        {
            MessageBox.Show("Det gick inte att spara produktlistan: " + ex.Message);
        }

    }

    public static async Task LoadProductsFromFile()
    {
        try
        {
            string productFilePath =
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "products.json");

            using (StreamReader reader = new StreamReader(productFilePath))
            {
                string productJson = await reader.ReadToEndAsync();
                ((List<Product>)_products).Clear();
                ((List<Product>)_products).AddRange( (JsonConvert.DeserializeObject<List<Products>>(productJson) ?? new List<Products>()));
            }

        }
        catch (Exception ex)
        {
            MessageBox.Show("Det gick inte att ladda produktlistan:  " + ex.Message);
        }
    }
}